import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function ResultPage() {
  const [rollNumber, setRollNumber] = useState("");
  const [resultData, setResultData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);

  const getApplicationQuery = trpc.application.getByRoll.useQuery(
    { roll: rollNumber },
    { enabled: false }
  );

  const getMarksQuery = trpc.marks.getByRoll.useQuery(
    { roll: rollNumber },
    { enabled: false }
  );

  const calculateGrade = (mark: number): string => {
    if (mark >= 95) return "A+";
    if (mark >= 85) return "A";
    if (mark >= 75) return "B+";
    if (mark >= 65) return "B";
    if (mark >= 55) return "C";
    if (mark >= 50) return "D";
    return "Fail";
  };

  const handleCheckResult = async () => {
    if (!rollNumber.trim()) {
      toast.error("Enter roll number");
      return;
    }

    setIsLoading(true);
    try {
      const [appData, marksData] = await Promise.all([
        getApplicationQuery.refetch(),
        getMarksQuery.refetch(),
      ]);

      if (!appData.data) {
        toast.error("Roll number not found");
        setResultData(null);
        return;
      }

      const marks = marksData.data || [];
      const markValues = marks.map((m) => m.marks);
      const avgMark = markValues.length ? markValues.reduce((a, b) => a + b, 0) / markValues.length : 0;
      const grade = markValues.length ? calculateGrade(avgMark) : "N/A";

      setResultData({
        ...appData.data,
        marks: markValues,
        avgMark: avgMark.toFixed(2),
        grade,
      });
    } catch (error) {
      toast.error("Error fetching result");
      setResultData(null);
    } finally {
      setIsLoading(false);
    }
  };

  const handlePrintResult = () => {
    if (!resultData) {
      toast.error("No result to print");
      return;
    }

    const printWindow = window.open("", "_blank");
    if (!printWindow) {
      toast.error("Please allow popups to print");
      return;
    }

    const resultHTML = `
      <html>
        <head>
          <title>Result Card - Dua Educational Academy</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 0; padding: 20px; }
            .slip-wrapper { border: 3px solid #28a745; padding: 25px; border-radius: 12px; }
            .academy-title { font-size: 24px; font-weight: bold; color: #00306e; text-align: center; margin-bottom: 20px; }
            .slip-box { display: flex; gap: 20px; margin: 20px 0; }
            .stu-photo { width: 140px; height: 160px; object-fit: cover; border: 2px solid #28a745; border-radius: 10px; }
            .roll-style { font-size: 18px; padding: 5px 15px; color: white; background: #28a745; border-radius: 8px; display: inline-block; font-weight: bold; }
            .sign-row { display: flex; justify-content: space-between; margin-top: 40px; padding-top: 20px; border-top: 1px solid #ccc; }
            @media print { body { -webkit-print-color-adjust: exact; print-color-adjust: exact; } }
          </style>
        </head>
        <body>
          <div class="slip-wrapper">
            <div class="academy-title">Dua Educational Academy Kamoon Shaheed</div>
            
            <div class="slip-box">
              <div>
                <img src="${resultData.photoUrl || ''}" class="stu-photo" onerror="this.style.display='none'">
              </div>
              
              <div>
                <div style="font-size: 20px; margin-bottom: 10px; color: #00306e; font-weight: 700;">Result Card</div>
                
                <div style="margin: 4px 0; font-size: 15px;"><strong>Name:</strong> ${resultData.name} ${resultData.surname}</div>
                <div style="margin: 4px 0; font-size: 15px;"><strong>Class:</strong> ${resultData.class}</div>
                <div style="margin: 4px 0; font-size: 15px;"><strong>Roll Number:</strong> <span class="roll-style">${resultData.roll}</span></div>
                
                <div style="margin-top: 10px; font-size: 16px; color: #00306e; font-weight: 600;">Marks Details</div>
                <div style="margin: 4px 0; font-size: 15px;"><strong>Marks:</strong> ${resultData.marks.length ? resultData.marks.join(', ') : 'Not uploaded yet'}</div>
                <div style="margin: 4px 0; font-size: 15px;"><strong>Average:</strong> ${resultData.avgMark}</div>
                <div style="margin: 4px 0; font-size: 15px;"><strong>Grade:</strong> <span style="font-size:18px;color:${resultData.grade === 'Fail' ? 'red' : 'green'}">${resultData.grade}</span></div>
                
                <div style="margin: 4px 0; font-size: 15px;"><strong>Father:</strong> ${resultData.fatherName} ${resultData.fatherSurname}</div>
                <div style="margin: 4px 0; font-size: 15px;"><strong>CNIC:</strong> ${resultData.fatherCnic}</div>
              </div>
            </div>
            
            <div class="sign-row">
              <div>
                <div style="text-align: center; font-size: 14px; margin-top: 5px; font-weight: 600;">Director Signature</div>
              </div>
              <div>
                <div style="text-align: center; font-size: 14px; margin-top: 5px; font-weight: 600;">Official Stamp</div>
              </div>
            </div>
          </div>
        </body>
      </html>
    `;

    printWindow.document.write(resultHTML);
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => {
      printWindow.print();
      printWindow.close();
    }, 500);
  };

  return (
    <section
      style={{
        background: "#f7f8f9",
        padding: "8px",
        borderRadius: "6px",
        textAlign: "center",
      }}
    >
      <div style={{ padding: "8px", background: "#f6f7f8", borderRadius: "6px" }}>
        <h2 style={{ color: "#4f05fd", marginBottom: "10px" }}>Result</h2>

        <label style={{ display: "block", fontWeight: 500, marginBottom: "6px", color: "#334155" }}>
          Enter Roll Number
          <input
            type="text"
            value={rollNumber}
            onChange={(e) => setRollNumber(e.target.value)}
            style={{
              width: "100%",
              maxWidth: "300px",
              padding: "10px",
              borderRadius: "8px",
              border: "1px solid rgba(6,40,61,0.06)",
              marginBottom: "5px",
              fontSize: "12px",
              boxSizing: "border-box",
            }}
          />
        </label>

        <div style={{ display: "flex", gap: "8px", justifyContent: "center", marginBottom: "20px" }}>
          <button
            onClick={handleCheckResult}
            disabled={isLoading}
            style={{
              background: "linear-gradient(90deg,#4f05fd,#f404a0)",
              color: "#fff",
              border: "none",
              padding: "10px 20px",
              borderRadius: "8px",
              fontWeight: "700",
              cursor: isLoading ? "not-allowed" : "pointer",
              opacity: isLoading ? 0.7 : 1,
            }}
          >
            {isLoading ? "Loading..." : "Check Result"}
          </button>
          <button
            onClick={handlePrintResult}
            style={{
              background: "transparent",
              color: "#4f05fd",
              border: "2px solid #4f05fd",
              padding: "10px 20px",
              borderRadius: "8px",
              fontWeight: "700",
              cursor: "pointer",
            }}
          >
            Print / Save PDF
          </button>
        </div>

        {resultData ? (
          <div
            style={{
              border: "3px solid #28a745",
              padding: "25px",
              borderRadius: "12px",
              background: "white",
              marginTop: "12px",
              textAlign: "left",
            }}
          >
            <div style={{ textAlign: "center", marginBottom: "18px" }}>
              <div style={{ fontSize: "24px", fontWeight: "800", color: "#00306e" }}>
                Dua Educational Academy Kamoon Shaheed
              </div>
            </div>

            <div style={{ display: "flex", gap: "20px", margin: "20px 0" }}>
              {resultData.photoUrl && (
                <div>
                  <img
                    src={resultData.photoUrl}
                    alt="Student"
                    style={{
                      width: "140px",
                      height: "160px",
                      objectFit: "cover",
                      border: "2px solid #28a745",
                      borderRadius: "10px",
                    }}
                  />
                </div>
              )}

              <div style={{ flex: 1 }}>
                <div style={{ fontSize: "20px", marginBottom: "10px", color: "#00306e", fontWeight: "700" }}>
                  Result Card
                </div>

                <div style={{ margin: "4px 0", fontSize: "15px" }}>
                  <strong>Name:</strong> {resultData.name} {resultData.surname}
                </div>
                <div style={{ margin: "4px 0", fontSize: "15px" }}>
                  <strong>Class:</strong> {resultData.class}
                </div>
                <div style={{ margin: "4px 0", fontSize: "15px" }}>
                  <strong>Roll Number:</strong>{" "}
                  <span
                    style={{
                      fontSize: "18px",
                      padding: "5px 15px",
                      color: "white",
                      background: "#28a745",
                      borderRadius: "8px",
                      display: "inline-block",
                      fontWeight: "bold",
                    }}
                  >
                    {resultData.roll}
                  </span>
                </div>

                <div style={{ marginTop: "10px", fontSize: "16px", color: "#00306e", fontWeight: "600" }}>
                  Marks Details
                </div>
                <div style={{ margin: "4px 0", fontSize: "15px" }}>
                  <strong>Marks:</strong> {resultData.marks.length ? resultData.marks.join(", ") : "Not uploaded yet"}
                </div>
                <div style={{ margin: "4px 0", fontSize: "15px" }}>
                  <strong>Average:</strong> {resultData.avgMark}
                </div>
                <div style={{ margin: "4px 0", fontSize: "15px" }}>
                  <strong>Grade:</strong>{" "}
                  <span
                    style={{
                      fontSize: "18px",
                      color: resultData.grade === "Fail" ? "red" : "green",
                    }}
                  >
                    {resultData.grade}
                  </span>
                </div>

                <div style={{ margin: "4px 0", fontSize: "15px", marginTop: "10px" }}>
                  <strong>Father:</strong> {resultData.fatherName} {resultData.fatherSurname}
                </div>
                <div style={{ margin: "4px 0", fontSize: "15px" }}>
                  <strong>CNIC:</strong> {resultData.fatherCnic}
                </div>
              </div>
            </div>

            <div style={{ marginTop: "25px", display: "flex", justifyContent: "space-between", padding: "0 20px" }}>
              <div>
                <div style={{ textAlign: "center", fontSize: "14px", marginTop: "5px", fontWeight: "600" }}>
                  Director Signature
                </div>
              </div>
              <div>
                <div style={{ textAlign: "center", fontSize: "14px", marginTop: "5px", fontWeight: "600" }}>
                  Official Stamp
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div style={{ color: "#999", padding: "20px", textAlign: "center" }}>
            Enter a roll number and click "Check Result" to view the result card
          </div>
        )}
      </div>
    </section>
  );
}
