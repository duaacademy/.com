import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function AdminPage() {
  const [adminPassword, setAdminPassword] = useState("");
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [applications, setApplications] = useState<any[]>([]);
  const [editingRoll, setEditingRoll] = useState<string | null>(null);
  const [editData, setEditData] = useState<any>({});

  const adminLoginMutation = trpc.admin.login.useMutation();
  const getAllApplicationsQuery = trpc.application.getAll.useQuery(undefined, {
    enabled: false,
  });
  const updatePaymentMutation = trpc.admin.updatePaymentStatus.useMutation();
  const updateApplicationMutation = trpc.application.update.useMutation();
  const deleteApplicationMutation = trpc.application.delete.useMutation();

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!adminPassword) {
      toast.error("Enter password");
      return;
    }

    setIsLoading(true);
    try {
      await adminLoginMutation.mutateAsync({ password: adminPassword });
      setIsLoggedIn(true);
      setAdminPassword("");
      toast.success("Admin login successful");

      // Load all applications
      const data = await getAllApplicationsQuery.refetch();
      if (data.data) {
        setApplications(data.data);
      }
    } catch (error) {
      toast.error("Wrong password");
    } finally {
      setIsLoading(false);
    }
  };

  const handleApprovePayment = async (roll: string) => {
    try {
      await updatePaymentMutation.mutateAsync({
        roll,
        status: "Approved",
      });
      setApplications((prev) =>
        prev.map((app) => (app.roll === roll ? { ...app, paymentStatus: "Approved" } : app))
      );
      toast.success("Payment approved");
    } catch (error) {
      toast.error("Failed to approve payment");
    }
  };

  const handleRejectPayment = async (roll: string) => {
    try {
      await updatePaymentMutation.mutateAsync({
        roll,
        status: "Rejected",
      });
      setApplications((prev) =>
        prev.map((app) => (app.roll === roll ? { ...app, paymentStatus: "Rejected" } : app))
      );
      toast.success("Payment rejected");
    } catch (error) {
      toast.error("Failed to reject payment");
    }
  };

  const handleDeleteApplication = async (roll: string) => {
    if (!confirm("Are you sure you want to delete this application?")) return;

    try {
      await deleteApplicationMutation.mutateAsync({ roll });
      setApplications((prev) => prev.filter((app) => app.roll !== roll));
      toast.success("Application deleted");
    } catch (error) {
      toast.error("Failed to delete application");
    }
  };

  const handleSaveChanges = async (roll: string) => {
    try {
      await updateApplicationMutation.mutateAsync({
        roll,
        data: editData,
      });
      setApplications((prev) =>
        prev.map((app) => (app.roll === roll ? { ...app, ...editData } : app))
      );
      setEditingRoll(null);
      setEditData({});
      toast.success("Changes saved");
    } catch (error) {
      toast.error("Failed to save changes");
    }
  };

  if (!isLoggedIn) {
    return (
      <section
        style={{
          background: "#f7f8f9",
          padding: "12px",
          borderRadius: "10px",
          textAlign: "center",
        }}
      >
        <div style={{ padding: "12px", background: "#f0f9ff", borderRadius: "10px" }}>
          <h2 style={{ color: "#4f05fd", marginBottom: "10px" }}>Admin Panel</h2>

          <form onSubmit={handleAdminLogin} style={{ maxWidth: "300px", margin: "0 auto" }}>
            <label style={{ display: "block", fontWeight: 500, marginBottom: "6px", color: "#334155" }}>
              Password
              <input
                type="password"
                value={adminPassword}
                onChange={(e) => setAdminPassword(e.target.value)}
                required
                style={{
                  width: "100%",
                  padding: "10px",
                  borderRadius: "8px",
                  border: "1px solid rgba(6,40,61,0.06)",
                  marginBottom: "5px",
                  fontSize: "12px",
                  boxSizing: "border-box",
                }}
              />
            </label>

            <button
              type="submit"
              disabled={isLoading}
              style={{
                width: "100%",
                background: "linear-gradient(90deg,#4f05fd,#f404a0)",
                color: "#fff",
                border: "none",
                padding: "10px 12px",
                borderRadius: "8px",
                fontWeight: "700",
                cursor: isLoading ? "not-allowed" : "pointer",
                opacity: isLoading ? 0.7 : 1,
              }}
            >
              {isLoading ? "Logging in..." : "Login"}
            </button>
          </form>
        </div>
      </section>
    );
  }

  return (
    <section
      style={{
        background: "#f7f8f9",
        padding: "12px",
        borderRadius: "10px",
      }}
    >
      <div style={{ padding: "12px", background: "#f0f9ff", borderRadius: "10px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
          <h2 style={{ color: "#4f05fd", margin: "0" }}>Admin Panel</h2>
          <button
            onClick={() => {
              setIsLoggedIn(false);
              setApplications([]);
              toast.success("Logged out");
            }}
            style={{
              background: "transparent",
              color: "#4f05fd",
              border: "2px solid #4f05fd",
              padding: "8px 16px",
              borderRadius: "8px",
              fontWeight: "700",
              cursor: "pointer",
            }}
          >
            Logout
          </button>
        </div>

        <h4 style={{ margin: "0 0 15px 0", color: "#4f05fd" }}>Applications & Marks (editable)</h4>

        <div style={{ overflowX: "auto" }}>
          <table
            style={{
              width: "100%",
              borderCollapse: "collapse",
              marginTop: "12px",
            }}
          >
            <thead>
              <tr style={{ background: "linear-gradient(90deg,#4f05fd,#f404a0)", color: "#fff" }}>
                <th style={{ border: "1px solid #e6eef6", padding: "8px", textAlign: "left", fontSize: "12px" }}>
                  Roll
                </th>
                <th style={{ border: "1px solid #e6eef6", padding: "8px", textAlign: "left", fontSize: "12px" }}>
                  Name
                </th>
                <th style={{ border: "1px solid #e6eef6", padding: "8px", textAlign: "left", fontSize: "12px" }}>
                  Class
                </th>
                <th style={{ border: "1px solid #e6eef6", padding: "8px", textAlign: "left", fontSize: "12px" }}>
                  Payment Status
                </th>
                <th style={{ border: "1px solid #e6eef6", padding: "8px", textAlign: "left", fontSize: "12px" }}>
                  Payment From
                </th>
                <th style={{ border: "1px solid #e6eef6", padding: "8px", textAlign: "left", fontSize: "12px" }}>
                  Actions
                </th>
              </tr>
            </thead>
            <tbody>
              {applications.map((app) => (
                <tr key={app.roll} style={{ background: "white" }}>
                  <td style={{ border: "1px solid #e6eef6", padding: "8px", fontSize: "12px" }}>{app.roll}</td>
                  <td style={{ border: "1px solid #e6eef6", padding: "8px", fontSize: "12px" }}>
                    {app.name} {app.surname}
                  </td>
                  <td style={{ border: "1px solid #e6eef6", padding: "8px", fontSize: "12px" }}>{app.class}</td>
                  <td
                    style={{
                      border: "1px solid #e6eef6",
                      padding: "8px",
                      fontSize: "12px",
                      color:
                        app.paymentStatus === "Approved"
                          ? "green"
                          : app.paymentStatus === "Rejected"
                            ? "red"
                            : "orange",
                    }}
                  >
                    {app.paymentStatus}
                  </td>
                  <td style={{ border: "1px solid #e6eef6", padding: "8px", fontSize: "12px" }}>
                    {app.paymentSenderNumber || "N/A"}
                  </td>
                  <td style={{ border: "1px solid #e6eef6", padding: "8px", fontSize: "12px" }}>
                    <div style={{ display: "flex", gap: "4px", flexWrap: "wrap" }}>
                      {app.paymentStatus === "Pending" && (
                        <>
                          <button
                            onClick={() => handleApprovePayment(app.roll)}
                            style={{
                              background: "green",
                              color: "#fff",
                              border: "none",
                              padding: "4px 8px",
                              borderRadius: "4px",
                              fontSize: "11px",
                              cursor: "pointer",
                              fontWeight: "600",
                            }}
                          >
                            Approve
                          </button>
                          <button
                            onClick={() => handleRejectPayment(app.roll)}
                            style={{
                              background: "red",
                              color: "#fff",
                              border: "none",
                              padding: "4px 8px",
                              borderRadius: "4px",
                              fontSize: "11px",
                              cursor: "pointer",
                              fontWeight: "600",
                            }}
                          >
                            Reject
                          </button>
                        </>
                      )}
                      <button
                        onClick={() => handleDeleteApplication(app.roll)}
                        style={{
                          background: "#f404a0",
                          color: "#fff",
                          border: "none",
                          padding: "4px 8px",
                          borderRadius: "4px",
                          fontSize: "11px",
                          cursor: "pointer",
                          fontWeight: "600",
                        }}
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {applications.length === 0 && (
          <div style={{ textAlign: "center", padding: "20px", color: "#999" }}>No applications found</div>
        )}
      </div>
    </section>
  );
}
