import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

interface ApplyPageProps {
  onNavigate: (section: string) => void;
}

export default function ApplyPage({ onNavigate }: ApplyPageProps) {
  const [formData, setFormData] = useState({
    stu_name: "",
    stu_surname: "",
    stu_gender: "",
    stu_dob: "",
    stu_cnic: "",
    stu_class: "",
    stu_pastSchool: "",
    stu_whatsapp: "",
    stu_photo: null as File | null,
    father_name: "",
    father_surname: "",
    father_cnic: "",
    father_occupation: "",
  });

  const [paymentData, setPaymentData] = useState({
    pay_student_name: "",
    pay_from_number: "",
    pay_txn: "",
    pay_screenshot: null as File | null,
  });

  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [photoPreview, setPhotoPreview] = useState<string>("");
  const [paymentPreview, setPaymentPreview] = useState<string>("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const createAppMutation = trpc.application.create.useMutation();

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { id, value } = e.target;
    setFormData((prev) => ({ ...prev, [id]: value }));
  };

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setFormData((prev) => ({ ...prev, stu_photo: file }));
      const reader = new FileReader();
      reader.onload = (e) => setPhotoPreview(e.target?.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handlePaymentScreenshotChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 10 * 1024 * 1024) {
        toast.error("File size should be less than 10MB");
        return;
      }
      setPaymentData((prev) => ({ ...prev, pay_screenshot: file }));
      const reader = new FileReader();
      reader.onload = (e) => setPaymentPreview(e.target?.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleProceedPayment = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.stu_name || !formData.stu_surname) {
      toast.error("Please enter student name and surname");
      return;
    }

    if (!formData.stu_class) {
      toast.error("Please select class");
      return;
    }

    if (formData.stu_cnic && formData.stu_cnic.length !== 13) {
      toast.error("Student CNIC must be 13 digits");
      return;
    }

    if (formData.father_cnic && formData.father_cnic.length !== 13) {
      toast.error("Father CNIC must be 13 digits");
      return;
    }

    if (formData.stu_whatsapp && formData.stu_whatsapp.length !== 11) {
      toast.error("WhatsApp number must be 11 digits");
      return;
    }

    setPaymentData((prev) => ({
      ...prev,
      pay_student_name: formData.stu_name,
    }));
    setShowPaymentModal(true);
  };

  const handlePaymentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!/^03[0-9]{9}$/.test(paymentData.pay_from_number)) {
      toast.error("Payment number must be in 03XXXXXXXXX format");
      return;
    }

    if (!paymentData.pay_txn) {
      toast.error("Enter transaction ID / reference");
      return;
    }

    if (!paymentData.pay_screenshot) {
      toast.error("Upload transaction screenshot");
      return;
    }

    setIsSubmitting(true);

    try {
      // Convert files to base64
      const photoBase64 = formData.stu_photo
        ? await new Promise<string>((resolve) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result as string);
            reader.readAsDataURL(formData.stu_photo!);
          })
        : "";

      const feeImageBase64 = await new Promise<string>((resolve) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as string);
        reader.readAsDataURL(paymentData.pay_screenshot!);
      });

      const result = await createAppMutation.mutateAsync({
        name: formData.stu_name,
        surname: formData.stu_surname,
        gender: formData.stu_gender,
        dob: formData.stu_dob,
        cnic: formData.stu_cnic,
        class: formData.stu_class,
        pastSchool: formData.stu_pastSchool,
        whatsapp: formData.stu_whatsapp,
        photoBase64,
        appFee: 650,
        paymentSenderNumber: paymentData.pay_from_number,
        txnId: paymentData.pay_txn,
        feeImageBase64,
        fatherName: formData.father_name,
        fatherSurname: formData.father_surname,
        fatherCnic: formData.father_cnic,
        fatherOccupation: formData.father_occupation,
      });

      toast.success(`✅ Application submitted successfully! Roll: ${result.roll}`);
      setShowPaymentModal(false);
      setFormData({
        stu_name: "",
        stu_surname: "",
        stu_gender: "",
        stu_dob: "",
        stu_cnic: "",
        stu_class: "",
        stu_pastSchool: "",
        stu_whatsapp: "",
        stu_photo: null,
        father_name: "",
        father_surname: "",
        father_cnic: "",
        father_occupation: "",
      });
      setPhotoPreview("");
      setPaymentPreview("");
    } catch (error) {
      toast.error("Failed to submit application");
      console.error(error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <>
      <section
        style={{
          background: "#f7f8f9",
          padding: "6px",
          borderRadius: "10px",
        }}
      >
        <div style={{ padding: "6px", background: "#f5f7f8", borderRadius: "10px", textAlign: "center" }}>
          <h3 style={{ margin: "0 0 10px 0" }}>Dua Educational Academy Kamoon Shaheed</h3>
          <h2 style={{ color: "#4f05fd", margin: "0 0 10px 0" }}>Online Apply Form</h2>

          <form onSubmit={handleProceedPayment} style={{ maxWidth: "600px", margin: "0 auto" }}>
            <h4 style={{ fontSize: "11px", color: "#4f05fd", marginBottom: "10px" }}>Student Information</h4>

            <label style={{ display: "block", fontWeight: 500, marginBottom: "6px", color: "#334155" }}>
              Name
              <input
                id="stu_name"
                value={formData.stu_name}
                onChange={handleInputChange}
                required
                style={{
                  width: "100%",
                  padding: "10px",
                  borderRadius: "8px",
                  border: "1px solid rgba(6,40,61,0.06)",
                  marginBottom: "5px",
                  fontSize: "12px",
                  boxSizing: "border-box",
                }}
              />
            </label>

            <label style={{ display: "block", fontWeight: 500, marginBottom: "6px", color: "#334155" }}>
              Surname
              <input
                id="stu_surname"
                value={formData.stu_surname}
                onChange={handleInputChange}
                required
                style={{
                  width: "100%",
                  padding: "10px",
                  borderRadius: "8px",
                  border: "1px solid rgba(6,40,61,0.06)",
                  marginBottom: "5px",
                  fontSize: "12px",
                  boxSizing: "border-box",
                }}
              />
            </label>

            <label style={{ display: "block", fontWeight: 500, marginBottom: "6px", color: "#334155" }}>
              Gender
              <select
                id="stu_gender"
                value={formData.stu_gender}
                onChange={handleInputChange}
                required
                style={{
                  width: "100%",
                  padding: "10px",
                  borderRadius: "8px",
                  border: "1px solid rgba(6,40,61,0.06)",
                  marginBottom: "5px",
                  fontSize: "12px",
                  boxSizing: "border-box",
                }}
              >
                <option value="">Select Gender</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
              </select>
            </label>

            <label style={{ display: "block", fontWeight: 500, marginBottom: "6px", color: "#334155" }}>
              Date of Birth
              <input
                id="stu_dob"
                type="date"
                value={formData.stu_dob}
                onChange={handleInputChange}
                required
                style={{
                  width: "100%",
                  padding: "10px",
                  borderRadius: "8px",
                  border: "1px solid rgba(6,40,61,0.06)",
                  marginBottom: "5px",
                  fontSize: "12px",
                  boxSizing: "border-box",
                }}
              />
            </label>

            <label style={{ display: "block", fontWeight: 500, marginBottom: "6px", color: "#334155" }}>
              CNIC (13 digits)
              <input
                id="stu_cnic"
                value={formData.stu_cnic}
                onChange={handleInputChange}
                maxLength={13}
                inputMode="numeric"
                pattern="[0-9]*"
                required
                style={{
                  width: "100%",
                  padding: "10px",
                  borderRadius: "8px",
                  border: "1px solid rgba(6,40,61,0.06)",
                  marginBottom: "5px",
                  fontSize: "12px",
                  boxSizing: "border-box",
                }}
              />
            </label>

            <label style={{ display: "block", fontWeight: 500, marginBottom: "6px", color: "#334155" }}>
              Class
              <select
                id="stu_class"
                value={formData.stu_class}
                onChange={handleInputChange}
                required
                style={{
                  width: "100%",
                  padding: "10px",
                  borderRadius: "8px",
                  border: "1px solid rgba(6,40,61,0.06)",
                  marginBottom: "5px",
                  fontSize: "12px",
                  boxSizing: "border-box",
                }}
              >
                <option value="">Select Class</option>
                <option value="5">5</option>
                <option value="6">6</option>
                <option value="7">7</option>
                <option value="8">8</option>
                <option value="9">9</option>
                <option value="10">10</option>
                <option value="11-Medical">11 - Medical</option>
                <option value="11-Eng">11 - Eng</option>
                <option value="12-Medical">12 - Medical</option>
                <option value="12-Eng">12 - Eng</option>
              </select>
            </label>

            <label style={{ display: "block", fontWeight: 500, marginBottom: "6px", color: "#334155" }}>
              Past School Name
              <input
                id="stu_pastSchool"
                value={formData.stu_pastSchool}
                onChange={handleInputChange}
                style={{
                  width: "100%",
                  padding: "10px",
                  borderRadius: "8px",
                  border: "1px solid rgba(6,40,61,0.06)",
                  marginBottom: "5px",
                  fontSize: "12px",
                  boxSizing: "border-box",
                }}
              />
            </label>

            <label style={{ display: "block", fontWeight: 500, marginBottom: "6px", color: "#334155" }}>
              WhatsApp Number (11 digits)
              <input
                id="stu_whatsapp"
                value={formData.stu_whatsapp}
                onChange={handleInputChange}
                maxLength={11}
                inputMode="numeric"
                pattern="[0-9]*"
                style={{
                  width: "100%",
                  padding: "10px",
                  borderRadius: "8px",
                  border: "1px solid rgba(6,40,61,0.06)",
                  marginBottom: "5px",
                  fontSize: "12px",
                  boxSizing: "border-box",
                }}
              />
            </label>

            <label style={{ display: "block", fontWeight: 500, marginBottom: "6px", color: "#334155" }}>
              Upload Photo (optional)
              <input
                id="stu_photo"
                type="file"
                accept="image/*"
                onChange={handlePhotoChange}
                style={{
                  width: "100%",
                  padding: "10px",
                  borderRadius: "8px",
                  border: "1px solid rgba(6,40,61,0.06)",
                  marginBottom: "5px",
                  fontSize: "12px",
                  boxSizing: "border-box",
                }}
              />
            </label>

            <h4 style={{ fontSize: "11px", color: "#4f05fd", marginBottom: "10px", marginTop: "15px" }}>
              Father Information
            </h4>

            <label style={{ display: "block", fontWeight: 500, marginBottom: "6px", color: "#334155" }}>
              Father Name
              <input
                id="father_name"
                value={formData.father_name}
                onChange={handleInputChange}
                required
                style={{
                  width: "100%",
                  padding: "10px",
                  borderRadius: "8px",
                  border: "1px solid rgba(6,40,61,0.06)",
                  marginBottom: "5px",
                  fontSize: "12px",
                  boxSizing: "border-box",
                }}
              />
            </label>

            <label style={{ display: "block", fontWeight: 500, marginBottom: "6px", color: "#334155" }}>
              Father Surname
              <input
                id="father_surname"
                value={formData.father_surname}
                onChange={handleInputChange}
                required
                style={{
                  width: "100%",
                  padding: "10px",
                  borderRadius: "8px",
                  border: "1px solid rgba(6,40,61,0.06)",
                  marginBottom: "5px",
                  fontSize: "12px",
                  boxSizing: "border-box",
                }}
              />
            </label>

            <label style={{ display: "block", fontWeight: 500, marginBottom: "6px", color: "#334155" }}>
              Father CNIC (13 digits)
              <input
                id="father_cnic"
                value={formData.father_cnic}
                onChange={handleInputChange}
                maxLength={13}
                inputMode="numeric"
                pattern="[0-9]*"
                required
                style={{
                  width: "100%",
                  padding: "10px",
                  borderRadius: "8px",
                  border: "1px solid rgba(6,40,61,0.06)",
                  marginBottom: "5px",
                  fontSize: "12px",
                  boxSizing: "border-box",
                }}
              />
            </label>

            <label style={{ display: "block", fontWeight: 500, marginBottom: "6px", color: "#334155" }}>
              Occupation
              <input
                id="father_occupation"
                value={formData.father_occupation}
                onChange={handleInputChange}
                style={{
                  width: "100%",
                  padding: "10px",
                  borderRadius: "8px",
                  border: "1px solid rgba(6,40,61,0.06)",
                  marginBottom: "5px",
                  fontSize: "12px",
                  boxSizing: "border-box",
                }}
              />
            </label>

            <h4 style={{ fontSize: "11px", color: "#4f05fd", marginBottom: "10px", marginTop: "15px" }}>Payment</h4>

            <label style={{ display: "block", fontWeight: 500, marginBottom: "6px", color: "#334155" }}>
              Application Fee
              <input
                type="text"
                value="650"
                readOnly
                style={{
                  width: "100%",
                  padding: "10px",
                  borderRadius: "8px",
                  border: "1px solid rgba(6,40,61,0.06)",
                  marginBottom: "5px",
                  fontSize: "12px",
                  boxSizing: "border-box",
                  backgroundColor: "#f5f5f5",
                }}
              />
            </label>

            <label style={{ fontSize: "11px", color: "#64748b", display: "block", marginBottom: "10px" }}>
              Click <strong>Proceed to Payment</strong> to open payment form and submit payment details (amount is
              fixed to 650).
            </label>

            <div style={{ display: "flex", gap: "8px" }}>
              <button
                type="submit"
                style={{
                  flex: 1,
                  background: "linear-gradient(90deg,#4f05fd,#f404a0)",
                  color: "#fff",
                  border: "none",
                  padding: "10px 12px",
                  borderRadius: "8px",
                  fontWeight: "700",
                  cursor: "pointer",
                }}
              >
                Proceed to Payment
              </button>
              <button
                type="button"
                onClick={() => {
                  setFormData({
                    stu_name: "",
                    stu_surname: "",
                    stu_gender: "",
                    stu_dob: "",
                    stu_cnic: "",
                    stu_class: "",
                    stu_pastSchool: "",
                    stu_whatsapp: "",
                    stu_photo: null,
                    father_name: "",
                    father_surname: "",
                    father_cnic: "",
                    father_occupation: "",
                  });
                  setPhotoPreview("");
                  toast.success("Form reset successfully");
                }}
                style={{
                  flex: 1,
                  background: "transparent",
                  color: "#4f05fd",
                  border: "2px solid #4f05fd",
                  padding: "10px 12px",
                  borderRadius: "8px",
                  fontWeight: "700",
                  cursor: "pointer",
                }}
              >
                Reset
              </button>
            </div>
          </form>
        </div>
      </section>

      {/* Payment Modal */}
      {showPaymentModal && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(2,6,23,0.6)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 9998,
          }}
        >
          <div
            style={{
              width: "420px",
              maxWidth: "95%",
              background: "rgb(228, 197, 197)",
              borderRadius: "12px",
              padding: "18px",
              boxShadow: "0 10px 30px rgba(2,6,23,0.3)",
            }}
          >
            <h3 style={{ marginTop: "0" }}>Payment Details</h3>
            <p style={{ fontSize: "12px" }}>
              Amount is fixed to <strong>650</strong>. Fill the payment details and upload transaction screenshot.
              Admin will verify and approve.
            </p>
            <h5 style={{ marginTop: "10px" }}>Jazzcash: 03083842741 (GADA HUSSAIN)</h5>

            <form onSubmit={handlePaymentSubmit}>
              <div style={{ display: "flex", gap: "10px", marginBottom: "10px" }}>
                <div style={{ flex: 1 }}>
                  <label style={{ display: "block", fontWeight: 500, marginBottom: "6px", color: "#334155" }}>
                    Student Name
                    <input
                      type="text"
                      value={paymentData.pay_student_name}
                      readOnly
                      style={{
                        width: "100%",
                        padding: "10px",
                        borderRadius: "8px",
                        border: "1px solid rgba(6,40,61,0.06)",
                        marginBottom: "5px",
                        fontSize: "12px",
                        boxSizing: "border-box",
                        backgroundColor: "#f5f5f5",
                      }}
                    />
                  </label>
                </div>
                <div style={{ flex: 1 }}>
                  <label style={{ display: "block", fontWeight: 500, marginBottom: "6px", color: "#334155" }}>
                    Amount
                    <input
                      type="text"
                      value="650"
                      readOnly
                      style={{
                        width: "100%",
                        padding: "10px",
                        borderRadius: "8px",
                        border: "1px solid rgba(6,40,61,0.06)",
                        marginBottom: "5px",
                        fontSize: "12px",
                        boxSizing: "border-box",
                        backgroundColor: "#f5f5f5",
                      }}
                    />
                  </label>
                </div>
              </div>

              <div style={{ display: "flex", gap: "10px", marginBottom: "10px" }}>
                <div style={{ flex: 1 }}>
                  <label style={{ display: "block", fontWeight: 500, marginBottom: "6px", color: "#334155" }}>
                    Payment From (Mobile Number)
                    <input
                      type="text"
                      value={paymentData.pay_from_number}
                      onChange={(e) =>
                        setPaymentData((prev) => ({ ...prev, pay_from_number: e.target.value }))
                      }
                      maxLength={11}
                      inputMode="numeric"
                      placeholder="03XXXXXXXXX"
                      required
                      style={{
                        width: "100%",
                        padding: "10px",
                        borderRadius: "8px",
                        border: "1px solid rgba(6,40,61,0.06)",
                        marginBottom: "5px",
                        fontSize: "12px",
                        boxSizing: "border-box",
                      }}
                    />
                  </label>
                </div>
                <div style={{ flex: 1 }}>
                  <label style={{ display: "block", fontWeight: 500, marginBottom: "6px", color: "#334155" }}>
                    Transaction ID / Ref
                    <input
                      type="text"
                      value={paymentData.pay_txn}
                      onChange={(e) => setPaymentData((prev) => ({ ...prev, pay_txn: e.target.value }))}
                      required
                      style={{
                        width: "100%",
                        padding: "10px",
                        borderRadius: "8px",
                        border: "1px solid rgba(6,40,61,0.06)",
                        marginBottom: "5px",
                        fontSize: "12px",
                        boxSizing: "border-box",
                      }}
                    />
                  </label>
                </div>
              </div>

              <label style={{ display: "block", fontWeight: 500, marginBottom: "6px", color: "#334155" }}>
                Upload Transaction Screenshot (required)
                <input
                  type="file"
                  accept="image/*"
                  onChange={handlePaymentScreenshotChange}
                  required
                  style={{
                    width: "100%",
                    padding: "10px",
                    borderRadius: "8px",
                    border: "1px solid rgba(6,40,61,0.06)",
                    marginBottom: "5px",
                    fontSize: "12px",
                    boxSizing: "border-box",
                  }}
                />
                <div style={{ fontSize: "11px", color: "#64748b" }}>Max size: 10MB • Formats: JPG, PNG</div>
              </label>

              {paymentPreview && (
                <div style={{ marginTop: "10px", textAlign: "center" }}>
                  <img
                    src={paymentPreview}
                    alt="Screenshot preview"
                    style={{ maxWidth: "100%", maxHeight: "150px", borderRadius: "5px" }}
                  />
                </div>
              )}

              <div style={{ display: "flex", gap: "8px", justifyContent: "flex-end", marginTop: "12px" }}>
                <button
                  type="button"
                  onClick={() => setShowPaymentModal(false)}
                  style={{
                    background: "transparent",
                    color: "#4f05fd",
                    border: "2px solid #4f05fd",
                    padding: "10px 12px",
                    borderRadius: "8px",
                    fontWeight: "700",
                    cursor: "pointer",
                  }}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  style={{
                    background: "linear-gradient(90deg,#4f05fd,#f404a0)",
                    color: "#fff",
                    border: "none",
                    padding: "10px 12px",
                    borderRadius: "8px",
                    fontWeight: "700",
                    cursor: isSubmitting ? "not-allowed" : "pointer",
                    opacity: isSubmitting ? 0.7 : 1,
                  }}
                >
                  {isSubmitting ? "Submitting..." : "Submit Payment & Save Application"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
}
