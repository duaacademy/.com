import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function MarksUploadPage() {
  const [marksPassword, setMarksPassword] = useState("");
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [rollNumber, setRollNumber] = useState("");
  const [marksValue, setMarksValue] = useState("");

  const adminLoginMutation = trpc.admin.login.useMutation();
  const addMarksMutation = trpc.marks.add.useMutation();

  const handleMarksLogin = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!marksPassword) {
      toast.error("Enter password");
      return;
    }

    setIsLoading(true);
    try {
      await adminLoginMutation.mutateAsync({ password: marksPassword });
      setIsLoggedIn(true);
      setMarksPassword("");
      toast.success("Marks upload access granted");
    } catch (error) {
      toast.error("Wrong password");
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveMarks = async () => {
    if (!rollNumber.trim() || marksValue === "") {
      toast.error("Enter roll number and marks");
      return;
    }

    try {
      await addMarksMutation.mutateAsync({
        roll: rollNumber,
        marks: Number(marksValue),
      });

      toast.success(`Marks uploaded for roll ${rollNumber}`);
      setRollNumber("");
      setMarksValue("");
    } catch (error) {
      toast.error("Failed to upload marks. Roll number may not exist.");
    }
  };

  if (!isLoggedIn) {
    return (
      <section
        style={{
          background: "#f7f8f9",
          padding: "12px",
          borderRadius: "10px",
          textAlign: "center",
        }}
      >
        <div style={{ padding: "12px", background: "#f0f9ff", borderRadius: "10px" }}>
          <h2 style={{ color: "#4f05fd", marginBottom: "10px" }}>Upload Marks (Single entry test)</h2>

          <form onSubmit={handleMarksLogin} style={{ maxWidth: "300px", margin: "0 auto" }}>
            <label style={{ display: "block", fontWeight: 500, marginBottom: "6px", color: "#334155" }}>
              Password
              <input
                type="password"
                value={marksPassword}
                onChange={(e) => setMarksPassword(e.target.value)}
                required
                style={{
                  width: "100%",
                  padding: "10px",
                  borderRadius: "8px",
                  border: "1px solid rgba(6,40,61,0.06)",
                  marginBottom: "5px",
                  fontSize: "12px",
                  boxSizing: "border-box",
                }}
              />
            </label>

            <button
              type="submit"
              disabled={isLoading}
              style={{
                width: "100%",
                background: "linear-gradient(90deg,#4f05fd,#f404a0)",
                color: "#fff",
                border: "none",
                padding: "10px 12px",
                borderRadius: "8px",
                fontWeight: "700",
                cursor: isLoading ? "not-allowed" : "pointer",
                opacity: isLoading ? 0.7 : 1,
              }}
            >
              {isLoading ? "Logging in..." : "Open"}
            </button>
          </form>
        </div>
      </section>
    );
  }

  return (
    <section
      style={{
        background: "#f7f8f9",
        padding: "12px",
        borderRadius: "10px",
        textAlign: "center",
      }}
    >
      <div style={{ padding: "12px", background: "#f0f9ff", borderRadius: "10px" }}>
        <h2 style={{ color: "#4f05fd", marginBottom: "10px" }}>Upload Marks</h2>

        <div style={{ maxWidth: "400px", margin: "0 auto" }}>
          <label style={{ display: "block", fontWeight: 500, marginBottom: "6px", color: "#334155" }}>
            Roll Number
            <input
              type="text"
              value={rollNumber}
              onChange={(e) => setRollNumber(e.target.value)}
              style={{
                width: "100%",
                padding: "10px",
                borderRadius: "8px",
                border: "1px solid rgba(6,40,61,0.06)",
                marginBottom: "5px",
                fontSize: "12px",
                boxSizing: "border-box",
              }}
            />
          </label>

          <label style={{ display: "block", fontWeight: 500, marginBottom: "6px", color: "#334155" }}>
            Marks (0-100)
            <input
              type="number"
              value={marksValue}
              onChange={(e) => setMarksValue(e.target.value)}
              min="0"
              max="100"
              style={{
                width: "100%",
                padding: "10px",
                borderRadius: "8px",
                border: "1px solid rgba(6,40,61,0.06)",
                marginBottom: "5px",
                fontSize: "12px",
                boxSizing: "border-box",
              }}
            />
          </label>

          <div style={{ display: "flex", gap: "8px" }}>
            <button
              onClick={handleSaveMarks}
              style={{
                flex: 1,
                background: "linear-gradient(90deg,#4f05fd,#f404a0)",
                color: "#fff",
                border: "none",
                padding: "10px 12px",
                borderRadius: "8px",
                fontWeight: "700",
                cursor: "pointer",
              }}
            >
              Upload Marks
            </button>
            <button
              onClick={() => setIsLoggedIn(false)}
              style={{
                flex: 1,
                background: "transparent",
                color: "#4f05fd",
                border: "2px solid #4f05fd",
                padding: "10px 12px",
                borderRadius: "8px",
                fontWeight: "700",
                cursor: "pointer",
              }}
            >
              Logout
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
