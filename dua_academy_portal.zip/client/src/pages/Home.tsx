import { useState } from "react";
import ApplyPage from "./Apply";
import SlipPage from "./Slip";
import ResultPage from "./Result";
import AdminPage from "./Admin";
import MarksUploadPage from "./MarksUpload";

export default function Home() {
  const [currentSection, setCurrentSection] = useState("home");

  const openSection = (id: string) => {
    setCurrentSection(id);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div className="min-h-screen" style={{ background: "linear-gradient(135deg,#16d2e7,#06434b)" }}>
      {/* Header */}
      <header
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          background: "linear-gradient(90deg,#4f05fd,#f404a0)",
          color: "#fff",
          padding: "8px",
          borderRadius: "6px",
          boxShadow: "0 8px 20px rgba(16, 84, 244, 0.08)",
          margin: "10px",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: "15px" }}>
          <img
            src="/logo.png"
            alt="Logo"
            style={{
              width: "36px",
              height: "36px",
              borderRadius: "8px",
              objectFit: "cover",
            }}
            onError={(e) => {
              (e.target as HTMLImageElement).style.display = "none";
            }}
          />
          <div>
            <h1 style={{ fontSize: "18px", margin: "0", color: "#fff" }}>Dua Educational Academy</h1>
            <div style={{ fontSize: "11px", color: "rgba(48, 15, 216, 0.9)" }}>
              Kamoon Shaheed - Online Portal
            </div>
          </div>
        </div>

        <nav style={{ display: "flex", gap: "8px", alignItems: "center", flexWrap: "wrap" }}>
          <a
            onClick={() => openSection("home")}
            style={{
              color: "#f5f5f3",
              textDecoration: "none",
              padding: "6px 8px",
              borderRadius: "8px",
              cursor: "pointer",
              fontWeight: "600",
              fontSize: "12px",
            }}
          >
            Home
          </a>
          <a
            onClick={() => openSection("apply")}
            style={{
              color: "#f5f5f3",
              textDecoration: "none",
              padding: "6px 8px",
              borderRadius: "8px",
              cursor: "pointer",
              fontWeight: "600",
              fontSize: "12px",
            }}
          >
            Apply
          </a>
          <a
            onClick={() => openSection("slip")}
            style={{
              color: "#f5f5f3",
              textDecoration: "none",
              padding: "6px 8px",
              borderRadius: "8px",
              cursor: "pointer",
              fontWeight: "600",
              fontSize: "12px",
            }}
          >
            Slip
          </a>
          <a
            onClick={() => openSection("result")}
            style={{
              color: "#f5f5f3",
              textDecoration: "none",
              padding: "6px 8px",
              borderRadius: "8px",
              cursor: "pointer",
              fontWeight: "600",
              fontSize: "12px",
            }}
          >
            Result
          </a>
          <a
            onClick={() => openSection("admin")}
            style={{
              color: "#f5f5f3",
              textDecoration: "none",
              padding: "6px 8px",
              borderRadius: "8px",
              cursor: "pointer",
              fontWeight: "600",
              fontSize: "12px",
            }}
          >
            Admin
          </a>
        </nav>
      </header>

      {/* Main Content */}
      <div style={{ maxWidth: "1200px", margin: "10px auto", padding: "12px" }}>
        {currentSection === "home" && (
          <section
            style={{
              background: "#f7f8f9",
              padding: "18px",
              borderRadius: "10px",
              boxShadow: "0 8px 20px rgba(16, 84, 244, 0.08)",
              textAlign: "center",
            }}
          >
            <img
              src="/logo.png"
              alt="Logo"
              style={{
                width: "80px",
                height: "80px",
                borderRadius: "8px",
                objectFit: "cover",
                marginBottom: "20px",
              }}
              onError={(e) => {
                (e.target as HTMLImageElement).style.display = "none";
              }}
            />
            <h2 style={{ color: "#4f05fd", marginBottom: "10px" }}>
              Welcome to Dua Educational Academy
            </h2>
            <p style={{ color: "#666", marginBottom: "20px" }}>
              Kamoon Shaheed - Online Portal for Student Applications, Results, and Admissions
            </p>
            <div style={{ display: "flex", gap: "8px", justifyContent: "center", flexWrap: "wrap" }}>
              <button
                onClick={() => openSection("apply")}
                style={{
                  background: "linear-gradient(90deg,#4f05fd,#f404a0)",
                  color: "#fff",
                  border: "none",
                  padding: "10px 20px",
                  borderRadius: "8px",
                  cursor: "pointer",
                  fontWeight: "700",
                }}
              >
                Apply Now
              </button>
              <button
                onClick={() => openSection("slip")}
                style={{
                  background: "transparent",
                  color: "#4f05fd",
                  border: "2px solid #4f05fd",
                  padding: "10px 20px",
                  borderRadius: "8px",
                  cursor: "pointer",
                  fontWeight: "700",
                }}
              >
                Check Slip
              </button>
              <button
                onClick={() => openSection("result")}
                style={{
                  background: "transparent",
                  color: "#4f05fd",
                  border: "2px solid #4f05fd",
                  padding: "10px 20px",
                  borderRadius: "8px",
                  cursor: "pointer",
                  fontWeight: "700",
                }}
              >
                Check Result
              </button>
            </div>
          </section>
        )}

        {currentSection === "apply" && <ApplyPage onNavigate={openSection} />}
        {currentSection === "slip" && <SlipPage />}
        {currentSection === "result" && <ResultPage />}
        {currentSection === "admin" && <AdminPage />}
        {currentSection === "marksUpload" && <MarksUploadPage />}
      </div>

      {/* Footer */}
      <footer
        style={{
          textAlign: "center",
          marginTop: "18px",
          fontSize: "11px",
          color: "#666",
          paddingBottom: "20px",
        }}
      >
        © Dua Educational Academy Kamoon Shaheed Portal • All Rights Reserved
      </footer>
    </div>
  );
}
