import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function SlipPage() {
  const [rollNumber, setRollNumber] = useState("");
  const [slipData, setSlipData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);

  const getApplicationQuery = trpc.application.getByRoll.useQuery(
    { roll: rollNumber },
    { enabled: false }
  );

  const handleGenerateSlip = async () => {
    if (!rollNumber.trim()) {
      toast.error("Enter roll number");
      return;
    }

    setIsLoading(true);
    try {
      const data = await getApplicationQuery.refetch();
      if (data.data) {
        if (data.data.paymentStatus !== "Approved") {
          setSlipData(null);
          toast.error("Payment Not Verified. Contact admin for verification.");
          return;
        }
        setSlipData(data.data);
      }
    } catch (error) {
      toast.error("Roll number not found");
      setSlipData(null);
    } finally {
      setIsLoading(false);
    }
  };

  const handlePrintSlip = () => {
    if (!slipData) {
      toast.error("No slip to print");
      return;
    }

    const printWindow = window.open("", "_blank");
    if (!printWindow) {
      toast.error("Please allow popups to print");
      return;
    }

    const slipHTML = `
      <html>
        <head>
          <title>Admit Slip - Dua Educational Academy</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 0; padding: 20px; }
            .slip-wrapper { border: 3px solid #0077ff; padding: 25px; border-radius: 12px; }
            .slip-header { text-align: center; margin-bottom: 18px; }
            .academy-logo { width: 40px; }
            .academy-title { font-size: 24px; font-weight: 800; color: #00306e; }
            .slip-box { display: flex; gap: 20px; background: #eaf3ff; padding: 20px; border-radius: 12px; margin: 20px 0; }
            .stu-photo { width: 140px; height: 160px; object-fit: cover; border: 2px solid #00306e; border-radius: 10px; }
            .data { flex: 1; }
            .slip-heading { font-size: 20px; margin-bottom: 10px; color: #00306e; font-weight: 700; }
            .field { margin: 4px 0; font-size: 15px; }
            .small-heading { margin-top: 10px; font-size: 16px; color: #00306e; font-weight: 600; }
            .roll-style { font-size: 18px; padding: 3px 10px; color: white; background: #0077ff; border-radius: 8px; font-weight: 700; display: inline-block; }
            .sign-row { margin-top: 25px; display: flex; justify-content: space-between; padding: 0 20px; }
            .sign-img { width: 140px; opacity: 0.9; }
            .stamp-img { width: 120px; opacity: 0.9; }
            .sign-text { text-align: center; font-size: 14px; margin-top: 5px; font-weight: 600; }
            @media print { body { -webkit-print-color-adjust: exact; print-color-adjust: exact; } }
          </style>
        </head>
        <body>
          <div class="slip-wrapper">
            <div class="slip-header">
              <div class="academy-title">Dua Educational Academy Kamoon Shaheed</div>
            </div>
            
            <div class="slip-box">
              <div>
                <img src="${slipData.photoUrl || ''}" class="stu-photo" onerror="this.style.display='none'">
              </div>
              
              <div class="data">
                <div class="slip-heading">Student Admit Slip</div>
                
                <div class="field"><strong>Name:</strong> ${slipData.name} ${slipData.surname}</div>
                <div class="field"><strong>Gender:</strong> ${slipData.gender} | <strong>DOB:</strong> ${slipData.dob}</div>
                <div class="field"><strong>CNIC:</strong> ${slipData.cnic}</div>
                <div class="field"><strong>Class:</strong> ${slipData.class}</div>
                
                <div class="small-heading">Roll Number</div>
                <div class="roll-style">${slipData.roll}</div>
                
                <div class="field"><strong>Application Fee:</strong> Rs. ${slipData.appFee}</div>
                <div class="field"><strong>Payment Status:</strong> <span style="color:green">${slipData.paymentStatus}</span></div>
                <div class="field"><strong>Payment From:</strong> ${slipData.paymentSenderNumber || 'N/A'}</div>
                <div class="field"><strong>WhatsApp:</strong> ${slipData.whatsapp || 'N/A'}</div>
                <div class="field"><strong>Past School:</strong> ${slipData.pastSchool || 'N/A'}</div>
                
                <div class="small-heading">Father Information</div>
                <div class="field"><strong>Name:</strong> ${slipData.fatherName} ${slipData.fatherSurname}</div>
                <div class="field"><strong>CNIC:</strong> ${slipData.fatherCnic}</div>
                <div class="field"><strong>Occupation:</strong> ${slipData.fatherOccupation || 'N/A'}</div>
              </div>
            </div>
            
            <div class="sign-row">
              <div>
                <div class="sign-text">Director Signature</div>
              </div>
              <div>
                <div class="sign-text">Official Stamp</div>
              </div>
            </div>
          </div>
        </body>
      </html>
    `;

    printWindow.document.write(slipHTML);
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => {
      printWindow.print();
      printWindow.close();
    }, 500);
  };

  return (
    <section
      style={{
        background: "#f7f8f9",
        padding: "12px",
        borderRadius: "10px",
        textAlign: "center",
      }}
    >
      <div style={{ padding: "12px", background: "#f0f9ff", borderRadius: "10px" }}>
        <h2 style={{ color: "#4f05fd", marginBottom: "10px" }}>Admit Slip</h2>

        <label style={{ display: "block", fontWeight: 500, marginBottom: "6px", color: "#334155" }}>
          Enter Roll Number
          <input
            type="text"
            value={rollNumber}
            onChange={(e) => setRollNumber(e.target.value)}
            style={{
              width: "100%",
              maxWidth: "300px",
              padding: "10px",
              borderRadius: "8px",
              border: "1px solid rgba(6,40,61,0.06)",
              marginBottom: "5px",
              fontSize: "12px",
              boxSizing: "border-box",
            }}
          />
        </label>

        <div style={{ display: "flex", gap: "8px", justifyContent: "center", marginBottom: "20px" }}>
          <button
            onClick={handleGenerateSlip}
            disabled={isLoading}
            style={{
              background: "linear-gradient(90deg,#4f05fd,#f404a0)",
              color: "#fff",
              border: "none",
              padding: "10px 20px",
              borderRadius: "8px",
              fontWeight: "700",
              cursor: isLoading ? "not-allowed" : "pointer",
              opacity: isLoading ? 0.7 : 1,
            }}
          >
            {isLoading ? "Loading..." : "Generate Slip"}
          </button>
          <button
            onClick={handlePrintSlip}
            style={{
              background: "transparent",
              color: "#4f05fd",
              border: "2px solid #4f05fd",
              padding: "10px 20px",
              borderRadius: "8px",
              fontWeight: "700",
              cursor: "pointer",
            }}
          >
            Print / Save PDF
          </button>
        </div>

        {slipData ? (
          <div
            style={{
              border: "3px solid #0077ff",
              padding: "25px",
              borderRadius: "12px",
              background: "white",
              marginTop: "12px",
              textAlign: "left",
            }}
          >
            <div style={{ textAlign: "center", marginBottom: "18px" }}>
              <div style={{ fontSize: "24px", fontWeight: "800", color: "#00306e" }}>
                Dua Educational Academy Kamoon Shaheed
              </div>
            </div>

            <div style={{ display: "flex", gap: "20px", background: "#eaf3ff", padding: "20px", borderRadius: "12px" }}>
              {slipData.photoUrl && (
                <div>
                  <img
                    src={slipData.photoUrl}
                    alt="Student"
                    style={{
                      width: "140px",
                      height: "160px",
                      objectFit: "cover",
                      border: "2px solid #00306e",
                      borderRadius: "10px",
                    }}
                  />
                </div>
              )}

              <div style={{ flex: 1 }}>
                <div style={{ fontSize: "20px", marginBottom: "10px", color: "#00306e", fontWeight: "700" }}>
                  Student Admit Slip
                </div>

                <div style={{ margin: "4px 0", fontSize: "15px" }}>
                  <strong>Name:</strong> {slipData.name} {slipData.surname}
                </div>
                <div style={{ margin: "4px 0", fontSize: "15px" }}>
                  <strong>Gender:</strong> {slipData.gender} | <strong>DOB:</strong> {slipData.dob}
                </div>
                <div style={{ margin: "4px 0", fontSize: "15px" }}>
                  <strong>CNIC:</strong> {slipData.cnic}
                </div>
                <div style={{ margin: "4px 0", fontSize: "15px" }}>
                  <strong>Class:</strong> {slipData.class}
                </div>

                <div style={{ marginTop: "10px", fontSize: "16px", color: "#00306e", fontWeight: "600" }}>
                  Roll Number
                </div>
                <div
                  style={{
                    fontSize: "18px",
                    padding: "3px 10px",
                    color: "white",
                    background: "#0077ff",
                    borderRadius: "8px",
                    fontWeight: "700",
                    display: "inline-block",
                  }}
                >
                  {slipData.roll}
                </div>

                <div style={{ margin: "4px 0", fontSize: "15px", marginTop: "10px" }}>
                  <strong>Application Fee:</strong> Rs. {slipData.appFee}
                </div>
                <div style={{ margin: "4px 0", fontSize: "15px" }}>
                  <strong>Payment Status:</strong> <span style={{ color: "green" }}>{slipData.paymentStatus}</span>
                </div>
                <div style={{ margin: "4px 0", fontSize: "15px" }}>
                  <strong>Payment From:</strong> {slipData.paymentSenderNumber || "N/A"}
                </div>
                <div style={{ margin: "4px 0", fontSize: "15px" }}>
                  <strong>WhatsApp:</strong> {slipData.whatsapp || "N/A"}
                </div>
                <div style={{ margin: "4px 0", fontSize: "15px" }}>
                  <strong>Past School:</strong> {slipData.pastSchool || "N/A"}
                </div>

                <div style={{ marginTop: "10px", fontSize: "16px", color: "#00306e", fontWeight: "600" }}>
                  Father Information
                </div>
                <div style={{ margin: "4px 0", fontSize: "15px" }}>
                  <strong>Name:</strong> {slipData.fatherName} {slipData.fatherSurname}
                </div>
                <div style={{ margin: "4px 0", fontSize: "15px" }}>
                  <strong>CNIC:</strong> {slipData.fatherCnic}
                </div>
                <div style={{ margin: "4px 0", fontSize: "15px" }}>
                  <strong>Occupation:</strong> {slipData.fatherOccupation || "N/A"}
                </div>
              </div>
            </div>

            <div style={{ marginTop: "25px", display: "flex", justifyContent: "space-between", padding: "0 20px" }}>
              <div>
                <div style={{ textAlign: "center", fontSize: "14px", marginTop: "5px", fontWeight: "600" }}>
                  Director Signature
                </div>
              </div>
              <div>
                <div style={{ textAlign: "center", fontSize: "14px", marginTop: "5px", fontWeight: "600" }}>
                  Official Stamp
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div style={{ color: "#999", padding: "20px", textAlign: "center" }}>
            Enter a roll number and click "Generate Slip" to view the admit slip
          </div>
        )}
      </div>
    </section>
  );
}
