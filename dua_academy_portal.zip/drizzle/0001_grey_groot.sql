CREATE TABLE `adminConfig` (
	`id` int AUTO_INCREMENT NOT NULL,
	`passwordHash` varchar(255) NOT NULL,
	`nextRoll` int NOT NULL DEFAULT 801,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `adminConfig_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `applications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`roll` varchar(20) NOT NULL,
	`name` varchar(100) NOT NULL,
	`surname` varchar(100) NOT NULL,
	`gender` varchar(20),
	`dob` varchar(20),
	`cnic` varchar(13),
	`class` varchar(50) NOT NULL,
	`pastSchool` varchar(200),
	`whatsapp` varchar(20),
	`photoUrl` text,
	`appFee` int NOT NULL DEFAULT 650,
	`paymentStatus` enum('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
	`paymentSenderNumber` varchar(20),
	`txnId` varchar(100),
	`feeImageUrl` text,
	`fatherName` varchar(100) NOT NULL,
	`fatherSurname` varchar(100) NOT NULL,
	`fatherCnic` varchar(13) NOT NULL,
	`fatherOccupation` varchar(100),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `applications_id` PRIMARY KEY(`id`),
	CONSTRAINT `applications_roll_unique` UNIQUE(`roll`)
);
--> statement-breakpoint
CREATE TABLE `marks` (
	`id` int AUTO_INCREMENT NOT NULL,
	`roll` varchar(20) NOT NULL,
	`marks` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `marks_id` PRIMARY KEY(`id`)
);
