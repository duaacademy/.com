import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Student Applications Table
 * Stores all student application data including personal info, father info, and payment details
 */
export const applications = mysqlTable("applications", {
  id: int("id").autoincrement().primaryKey(),
  roll: varchar("roll", { length: 20 }).notNull().unique(),
  name: varchar("name", { length: 100 }).notNull(),
  surname: varchar("surname", { length: 100 }).notNull(),
  gender: varchar("gender", { length: 20 }),
  dob: varchar("dob", { length: 20 }),
  cnic: varchar("cnic", { length: 13 }),
  class: varchar("class", { length: 50 }).notNull(),
  pastSchool: varchar("pastSchool", { length: 200 }),
  whatsapp: varchar("whatsapp", { length: 20 }),
  photoUrl: text("photoUrl"), // S3 URL for student photo
  appFee: int("appFee").notNull().default(650),
  paymentStatus: mysqlEnum("paymentStatus", ["Pending", "Approved", "Rejected"]).default("Pending").notNull(),
  paymentSenderNumber: varchar("paymentSenderNumber", { length: 20 }),
  txnId: varchar("txnId", { length: 100 }),
  feeImageUrl: text("feeImageUrl"), // S3 URL for payment screenshot
  fatherName: varchar("fatherName", { length: 100 }).notNull(),
  fatherSurname: varchar("fatherSurname", { length: 100 }).notNull(),
  fatherCnic: varchar("fatherCnic", { length: 13 }).notNull(),
  fatherOccupation: varchar("fatherOccupation", { length: 100 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Application = typeof applications.$inferSelect;
export type InsertApplication = typeof applications.$inferInsert;

/**
 * Marks Table
 * Stores student marks for result generation
 */
export const marks = mysqlTable("marks", {
  id: int("id").autoincrement().primaryKey(),
  roll: varchar("roll", { length: 20 }).notNull(),
  marks: int("marks").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Mark = typeof marks.$inferSelect;
export type InsertMark = typeof marks.$inferInsert;

/**
 * Admin Configuration Table
 * Stores admin settings and credentials
 */
export const adminConfig = mysqlTable("adminConfig", {
  id: int("id").autoincrement().primaryKey(),
  passwordHash: varchar("passwordHash", { length: 255 }).notNull(),
  nextRoll: int("nextRoll").default(801).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AdminConfig = typeof adminConfig.$inferSelect;
export type InsertAdminConfig = typeof adminConfig.$inferInsert;
