import { describe, expect, it, beforeAll, afterAll } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import type { User } from "../drizzle/schema";

// Mock context for testing
function createMockContext(): TrpcContext {
  const user: User = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "test",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("Application API", () => {
  let caller: ReturnType<typeof appRouter.createCaller>;
  let testRoll: string;

  beforeAll(() => {
    const ctx = createMockContext();
    caller = appRouter.createCaller(ctx);
  });

  describe("application.create", () => {
    it("should create a new application with valid data", async () => {
      const result = await caller.application.create({
        name: "Ahmed",
        surname: "Khan",
        gender: "Male",
        dob: "2005-01-15",
        cnic: "1234567890123",
        class: "10",
        pastSchool: "Government School",
        whatsapp: "03001234567",
        photoBase64: "",
        appFee: 650,
        paymentSenderNumber: "03001234567",
        txnId: "TXN123456",
        feeImageBase64: "data:image/jpeg;base64,/9j/4AAQSkZJRg==",
        fatherName: "Hassan",
        fatherSurname: "Khan",
        fatherCnic: "1234567890124",
        fatherOccupation: "Teacher",
      });

      expect(result.success).toBe(true);
      expect(result.roll).toBeDefined();
      expect(result.message).toBe("Application submitted successfully");
      testRoll = result.roll;
    });

    it("should fail without required fields", async () => {
      try {
        await caller.application.create({
          name: "",
          surname: "Khan",
          gender: "Male",
          dob: "2005-01-15",
          cnic: "1234567890123",
          class: "10",
          pastSchool: "",
          whatsapp: "",
          photoBase64: "",
          appFee: 650,
          paymentSenderNumber: "03001234567",
          txnId: "TXN123456",
          feeImageBase64: "data:image/jpeg;base64,/9j/4AAQSkZJRg==",
          fatherName: "Hassan",
          fatherSurname: "Khan",
          fatherCnic: "1234567890124",
          fatherOccupation: "",
        });
        expect.fail("Should have thrown an error");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });
  });

  describe("application.getByRoll", () => {
    it("should retrieve application by roll number", async () => {
      if (!testRoll) {
        console.log("Skipping test: testRoll not set");
        return;
      }

      const result = await caller.application.getByRoll({ roll: testRoll });
      expect(result).toBeDefined();
      expect(result.roll).toBe(testRoll);
      expect(result.name).toBe("Ahmed");
      expect(result.surname).toBe("Khan");
      expect(result.paymentStatus).toBe("Pending");
    });

    it("should return error for non-existent roll", async () => {
      try {
        await caller.application.getByRoll({ roll: "99999" });
        expect.fail("Should have thrown an error");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });
  });

  describe("application.getAll", () => {
    it("should retrieve all applications", async () => {
      const result = await caller.application.getAll();
      expect(Array.isArray(result)).toBe(true);
      expect(result.length).toBeGreaterThan(0);
    });
  });

  describe("admin.login", () => {
    it("should login with correct password", async () => {
      const result = await caller.admin.login({ password: "uk6091" });
      expect(result.success).toBe(true);
    });

    it("should fail with incorrect password", async () => {
      try {
        await caller.admin.login({ password: "wrongpassword" });
        expect.fail("Should have thrown an error");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });
  });

  describe("admin.updatePaymentStatus", () => {
    it("should update payment status to Approved", async () => {
      if (!testRoll) {
        console.log("Skipping test: testRoll not set");
        return;
      }

      const result = await caller.admin.updatePaymentStatus({
        roll: testRoll,
        status: "Approved",
      });
      expect(result.success).toBe(true);

      // Verify the update
      const app = await caller.application.getByRoll({ roll: testRoll });
      expect(app.paymentStatus).toBe("Approved");
    });

    it("should update payment status to Rejected", async () => {
      if (!testRoll) {
        console.log("Skipping test: testRoll not set");
        return;
      }

      const result = await caller.admin.updatePaymentStatus({
        roll: testRoll,
        status: "Rejected",
      });
      expect(result.success).toBe(true);

      // Verify the update
      const app = await caller.application.getByRoll({ roll: testRoll });
      expect(app.paymentStatus).toBe("Rejected");
    });
  });

  describe("marks.add", () => {
    it("should add marks for a student", async () => {
      if (!testRoll) {
        console.log("Skipping test: testRoll not set");
        return;
      }

      // First approve the application so marks can be added
      await caller.admin.updatePaymentStatus({
        roll: testRoll,
        status: "Approved",
      });

      const result = await caller.marks.add({
        roll: testRoll,
        marks: 85,
      });
      expect(result.success).toBe(true);
    });

    it("should fail for non-existent roll", async () => {
      try {
        await caller.marks.add({
          roll: "99999",
          marks: 85,
        });
        expect.fail("Should have thrown an error");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });
  });

  describe("marks.getByRoll", () => {
    it("should retrieve marks for a student", async () => {
      if (!testRoll) {
        console.log("Skipping test: testRoll not set");
        return;
      }

      const result = await caller.marks.getByRoll({ roll: testRoll });
      expect(Array.isArray(result)).toBe(true);
      expect(result.length).toBeGreaterThan(0);
      expect(result[0].marks).toBe(85);
    });
  });

  describe("application.update", () => {
    it("should update application data", async () => {
      if (!testRoll) {
        console.log("Skipping test: testRoll not set");
        return;
      }

      const result = await caller.application.update({
        roll: testRoll,
        data: {
          whatsapp: "03009876543",
        },
      });
      expect(result.success).toBe(true);

      // Verify the update
      const app = await caller.application.getByRoll({ roll: testRoll });
      expect(app.whatsapp).toBe("03009876543");
    });
  });

  describe("application.delete", () => {
    it("should delete application and associated marks", async () => {
      if (!testRoll) {
        console.log("Skipping test: testRoll not set");
        return;
      }

      const result = await caller.application.delete({ roll: testRoll });
      expect(result.success).toBe(true);

      // Verify deletion
      try {
        await caller.application.getByRoll({ roll: testRoll });
        expect.fail("Should have thrown an error");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });
  });
});
