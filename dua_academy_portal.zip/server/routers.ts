import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { storagePut, storageGet } from "./storage";
import { TRPCError } from "@trpc/server";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Application procedures
  application: router({
    // Create a new application
    create: publicProcedure
      .input(z.object({
        name: z.string().min(1),
        surname: z.string().min(1),
        gender: z.string(),
        dob: z.string(),
        cnic: z.string(),
        class: z.string().min(1),
        pastSchool: z.string().optional(),
        whatsapp: z.string().optional(),
        photoBase64: z.string().optional(),
        appFee: z.number().default(650),
        paymentSenderNumber: z.string(),
        txnId: z.string(),
        feeImageBase64: z.string(),
        fatherName: z.string().min(1),
        fatherSurname: z.string().min(1),
        fatherCnic: z.string(),
        fatherOccupation: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        try {
          // Get next roll number
          const roll = String(await db.getNextRoll());
          await db.incrementNextRoll();

          // Upload student photo if provided
          let photoUrl = "";
          if (input.photoBase64) {
            try {
              const photoBuffer = Buffer.from(input.photoBase64.split(",")[1] || input.photoBase64, "base64");
              const { url } = await storagePut(`applications/${roll}/photo.jpg`, photoBuffer);
              photoUrl = url;
            } catch (e) {
              console.error("Photo upload failed:", e);
            }
          }

          // Upload payment screenshot
          let feeImageUrl = "";
          try {
            const feeBuffer = Buffer.from(input.feeImageBase64.split(",")[1] || input.feeImageBase64, "base64");
            const { url } = await storagePut(`applications/${roll}/payment.jpg`, feeBuffer);
            feeImageUrl = url;
          } catch (e) {
            console.error("Payment screenshot upload failed:", e);
          }

          // Create application record
          const app = await db.createApplication({
            roll,
            name: input.name,
            surname: input.surname,
            gender: input.gender,
            dob: input.dob,
            cnic: input.cnic,
            class: input.class,
            pastSchool: input.pastSchool || "",
            whatsapp: input.whatsapp || "",
            photoUrl,
            appFee: input.appFee,
            paymentStatus: "Pending",
            paymentSenderNumber: input.paymentSenderNumber,
            txnId: input.txnId,
            feeImageUrl,
            fatherName: input.fatherName,
            fatherSurname: input.fatherSurname,
            fatherCnic: input.fatherCnic,
            fatherOccupation: input.fatherOccupation || "",
          });

          return {
            success: true,
            roll,
            message: "Application submitted successfully",
          };
        } catch (error) {
          console.error("Application creation error:", error);
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to create application",
          });
        }
      }),

    // Get application by roll number
    getByRoll: publicProcedure
      .input(z.object({ roll: z.string() }))
      .query(async ({ input }) => {
        const app = await db.getApplicationByRoll(input.roll);
        if (!app) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Application not found",
          });
        }
        return app;
      }),

    // Get all applications (admin only)
    getAll: publicProcedure.query(async () => {
      return await db.getAllApplications();
    }),

    // Update application (admin only)
    update: publicProcedure
      .input(z.object({
        roll: z.string(),
        data: z.record(z.string(), z.any()).optional(),
      }))
      .mutation(async ({ input }) => {
        const app = await db.getApplicationByRoll(input.roll);
        if (!app) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Application not found",
          });
        }

        await db.updateApplication(input.roll, input.data || {});
        return { success: true };
      }),

    // Delete application (admin only)
    delete: publicProcedure
      .input(z.object({ roll: z.string() }))
      .mutation(async ({ input }) => {
        await db.deleteApplication(input.roll);
        // Also delete associated marks
        await db.deleteMarksByRoll(input.roll);
        return { success: true };
      }),
  }),

  // Marks procedures
  marks: router({
    // Add marks for a student
    add: publicProcedure
      .input(z.object({
        roll: z.string(),
        marks: z.number().min(0).max(100),
      }))
      .mutation(async ({ input }) => {
        // Verify application exists
        const app = await db.getApplicationByRoll(input.roll);
        if (!app) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Application not found",
          });
        }

        await db.createMark({
          roll: input.roll,
          marks: input.marks,
        } as any);

        return { success: true };
      }),

    // Get marks for a student
    getByRoll: publicProcedure
      .input(z.object({ roll: z.string() }))
      .query(async ({ input }) => {
        return await db.getMarksByRoll(input.roll);
      }),

    // Delete marks for a student
    deleteByRoll: publicProcedure
      .input(z.object({ roll: z.string() }))
      .mutation(async ({ input }) => {
        await db.deleteMarksByRoll(input.roll);
        return { success: true };
      }),
  }),

  // Admin procedures
  admin: router({
    // Admin login (simple password verification)
    login: publicProcedure
      .input(z.object({ password: z.string() }))
      .mutation(async ({ input }) => {
        const ADMIN_PASSWORD = "uk6091"; // In production, use hashed password
        if (input.password !== ADMIN_PASSWORD) {
          throw new TRPCError({
            code: "UNAUTHORIZED",
            message: "Invalid password",
          });
        }
        return { success: true };
      }),

    // Update payment status
    updatePaymentStatus: publicProcedure
      .input(z.object({
        roll: z.string(),
        status: z.enum(["Pending", "Approved", "Rejected"]),
      }))
      .mutation(async ({ input }) => {
        const app = await db.getApplicationByRoll(input.roll);
        if (!app) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Application not found",
          });
        }

        await db.updateApplication(input.roll, {
          paymentStatus: input.status,
        });

        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
