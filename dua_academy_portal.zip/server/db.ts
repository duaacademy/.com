import { eq, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, applications, marks, adminConfig, InsertApplication, InsertMark } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Application queries
export async function createApplication(app: InsertApplication) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(applications).values(app);
  return result;
}

export async function getApplicationByRoll(roll: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.select().from(applications).where(eq(applications.roll, roll)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getAllApplications() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.select().from(applications).orderBy(desc(applications.createdAt));
}

export async function updateApplication(roll: string, data: Partial<InsertApplication>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.update(applications).set(data).where(eq(applications.roll, roll));
}

export async function deleteApplication(roll: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.delete(applications).where(eq(applications.roll, roll));
}

// Marks queries
export async function createMark(mark: InsertMark) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.insert(marks).values(mark);
}

export async function getMarksByRoll(roll: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.select().from(marks).where(eq(marks.roll, roll));
}

export async function deleteMarksByRoll(roll: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.delete(marks).where(eq(marks.roll, roll));
}

// Admin config queries
export async function getAdminConfig() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.select().from(adminConfig).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getNextRoll() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const config = await getAdminConfig();
  if (!config) {
    // Initialize admin config if not exists
    await db.insert(adminConfig).values({ passwordHash: '', nextRoll: 801 });
    return 801;
  }
  
  return config.nextRoll;
}

export async function incrementNextRoll() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const config = await getAdminConfig();
  if (!config) {
    await db.insert(adminConfig).values({ passwordHash: '', nextRoll: 802 });
    return 802;
  }
  
  const newRoll = config.nextRoll + 1;
  await db.update(adminConfig).set({ nextRoll: newRoll }).where(eq(adminConfig.id, config.id));
  return newRoll;
}
